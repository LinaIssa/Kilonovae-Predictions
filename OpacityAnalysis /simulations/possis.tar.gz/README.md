# possis
Radiative transfer code to simulate light curves, flux and polarization spectra for supernova and kilonova models.
A description of the code can be found in Bulla 2019
